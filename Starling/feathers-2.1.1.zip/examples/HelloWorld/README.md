# Hello World Example for Feathers

A very simple example that creates a Button control from the [Feathers](http://feathersui.com/) library, presented as a mobile app.

## Requirements

In addition to Starling Framwork and Feathers, this example project requires the MetalWorksMobileTheme example theme. You can find the SWC file for this theme at the following location in the Feathers release build:

	themes/MetalWorksMobileTheme/swc/MetalWorksMobileTheme.swc

## Web Demo

View the [Hello World Example](http://feathersui.com/examples/hello-world/) in your browser.